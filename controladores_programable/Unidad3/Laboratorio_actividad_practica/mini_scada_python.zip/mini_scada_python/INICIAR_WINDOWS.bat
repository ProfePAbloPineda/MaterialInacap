@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  echo No se encontro Python. Instale Python 3.10+ desde python.org y vuelva a ejecutar.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto fallo
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fallo
".venv\Scripts\python.exe" mini_scada.py
if errorlevel 1 goto fallo
exit /b 0
:fallo
echo Hubo un error. Revise los mensajes anteriores.
pause
exit /b 1
