"""Mini SCADA educativo: simulación y cliente Modbus TCP (PyModbus 3.11.x)."""
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    ModbusTcpClient = None

# Direcciones Modbus PDU (base cero). Adaptar al mapa publicado por el PLC.
REG_COMANDO = 0       # PC escribe: 1 = marcha, 0 = parada
REG_ESTADO = 1        # PLC publica: 1 = marcha, 0 = parado
REG_CICLOS = 2       # PLC publica: contador de ciclos
REG_ALARMA = 3       # PLC publica: 0 = normal, otro valor = alarma


class MiniScada:
    def __init__(self, root):
        self.root = root
        root.title('Mini SCADA — PLC Delta SE')
        root.geometry('590x425')
        root.minsize(520, 400)
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.worker = None
        self.command = queue.Queue()
        self.mode = tk.StringVar(value='Simulación')
        self.ip = tk.StringVar(value='192.168.10.20')
        self.port = tk.StringVar(value='502')
        self.unit = tk.StringVar(value='1')
        self.connection = tk.StringVar(value='Sin conexión')
        self.estado = tk.StringVar(value='DETENIDO')
        self.ciclos = tk.StringVar(value='0')
        self.alarma = tk.StringVar(value='Normal')
        self.sim_running = False
        self.sim_cycles = 0
        self.last_cycle = time.monotonic()
        self.build_ui()
        self.root.after(150, self.process_events)
        self.root.protocol('WM_DELETE_WINDOW', self.close)

    def build_ui(self):
        frame = ttk.Frame(self.root, padding=18)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='MINI SCADA | CONTROL DE PROCESO', font=('Segoe UI', 15, 'bold')).pack(anchor='w', pady=(0, 13))
        setup = ttk.LabelFrame(frame, text='Configuración', padding=10)
        setup.pack(fill='x')
        row1 = ttk.Frame(setup); row1.pack(fill='x', pady=3)
        ttk.Label(row1, text='Modo', width=9).pack(side='left')
        self.mode_box = ttk.Combobox(row1, textvariable=self.mode, values=['Simulación', 'Modbus TCP'], width=15, state='readonly')
        self.mode_box.pack(side='left', padx=(0, 8))
        ttk.Label(row1, text='IP').pack(side='left')
        self.ip_entry = ttk.Entry(row1, textvariable=self.ip, width=16); self.ip_entry.pack(side='left', padx=5)
        ttk.Label(row1, text='Puerto').pack(side='left')
        self.port_entry = ttk.Entry(row1, textvariable=self.port, width=6); self.port_entry.pack(side='left', padx=5)
        row2 = ttk.Frame(setup); row2.pack(fill='x', pady=3)
        ttk.Label(row2, text='Unit ID', width=9).pack(side='left')
        self.unit_entry = ttk.Entry(row2, textvariable=self.unit, width=6); self.unit_entry.pack(side='left')
        self.btn_connect = ttk.Button(row2, text='Conectar / iniciar', command=self.connect)
        self.btn_connect.pack(side='left', padx=12)
        self.btn_disconnect = ttk.Button(row2, text='Desconectar', command=self.disconnect)
        self.btn_disconnect.pack(side='left')
        ttk.Label(frame, textvariable=self.connection, foreground='#155e75').pack(anchor='w', pady=10)
        process = ttk.LabelFrame(frame, text='Proceso', padding=13)
        process.pack(fill='both', expand=True)
        self.status_lbl = ttk.Label(process, textvariable=self.estado, font=('Segoe UI', 17, 'bold'))
        self.status_lbl.pack(pady=6)
        buttons = ttk.Frame(process); buttons.pack(pady=6)
        self.start_button = ttk.Button(buttons, text='PARTIDA', command=lambda: self.send(1), state='disabled')
        self.start_button.pack(side='left', padx=8)
        self.stop_button = ttk.Button(buttons, text='PARADA', command=lambda: self.send(0), state='disabled')
        self.stop_button.pack(side='left', padx=8)
        info = ttk.Frame(process); info.pack(pady=15)
        ttk.Label(info, text='Ciclos:').grid(row=0, column=0, padx=5)
        ttk.Label(info, textvariable=self.ciclos, font=('Segoe UI', 14, 'bold')).grid(row=0, column=1, padx=5)
        ttk.Label(info, text='Alarma:').grid(row=0, column=2, padx=(26, 5))
        ttk.Label(info, textvariable=self.alarma).grid(row=0, column=3, padx=5)
        ttk.Label(frame, text='En Modbus TCP, el PLC debe implementar el mapa de registros documentado.', foreground='#666').pack(anchor='w', pady=(10, 0))

    def connect(self):
        if self.worker and self.worker.is_alive():
            return
        mode = self.mode.get()
        if mode == 'Modbus TCP':
            try:
                port = int(self.port.get()); unit = int(self.unit.get())
                if not 1 <= port <= 65535 or not 0 <= unit <= 247:
                    raise ValueError()
            except ValueError:
                messagebox.showerror('Configuración', 'Puerto o Unit ID no válido.')
                return
            if ModbusTcpClient is None:
                messagebox.showerror('Falta dependencia', 'Instale PyModbus: python -m pip install -r requirements.txt')
                return
        self.stop_event.clear()
        self.mode_box.configure(state='disabled')
        self.btn_connect.configure(state='disabled')
        self.start_button.configure(state='normal')
        self.stop_button.configure(state='normal')
        if mode == 'Simulación':
            self.connection.set('SIMULACIÓN — Sin PLC físico')
            self.sim_running = False
            self.last_cycle = time.monotonic()
            self.root.after(300, self.sim_tick)
        else:
            self.connection.set('Conectando al PLC...')
            self.worker = threading.Thread(target=self.modbus_loop, args=(self.ip.get(), port, unit), daemon=True)
            self.worker.start()

    def sim_tick(self):
        if self.stop_event.is_set() or self.mode.get() != 'Simulación':
            return
        now = time.monotonic()
        if self.sim_running and now - self.last_cycle >= 5:
            self.sim_cycles += 1
            self.last_cycle = now
        self.estado.set('EN MARCHA' if self.sim_running else 'DETENIDO')
        self.ciclos.set(str(self.sim_cycles))
        self.alarma.set('Normal')
        self.root.after(300, self.sim_tick)

    def send(self, value):
        if self.stop_event.is_set():
            return
        if self.mode.get() == 'Simulación':
            self.sim_running = bool(value)
            self.last_cycle = time.monotonic()
        else:
            self.command.put(value)

    def modbus_loop(self, host, port, unit):
        client = ModbusTcpClient(host, port=port, timeout=1.5, retries=0)
        try:
            if not client.connect():
                self.events.put(('error', f'No hay conexión TCP con {host}:{port}'))
                return
            self.events.put(('connected', f'MODBUS TCP — {host}:{port}'))
            while not self.stop_event.is_set():
                while not self.command.empty():
                    command = self.command.get_nowait()
                    result = client.write_register(address=REG_COMANDO, value=command, device_id=unit)
                    if result.isError():
                        raise RuntimeError(f'Error escribiendo registro: {result}')
                result = client.read_holding_registers(address=REG_ESTADO, count=3, device_id=unit)
                if result.isError() or len(result.registers) != 3:
                    raise RuntimeError(f'Error leyendo registros: {result}')
                self.events.put(('data', tuple(result.registers)))
                self.stop_event.wait(0.5)
        except Exception as exc:
            self.events.put(('error', f'Fallo de comunicación: {exc}'))
        finally:
            client.close()
            self.events.put(('disconnected', None))

    def process_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == 'connected':
                    self.connection.set(payload)
                elif kind == 'data':
                    estado, ciclos, alarma = payload
                    self.estado.set('EN MARCHA' if estado else 'DETENIDO')
                    self.ciclos.set(str(ciclos))
                    self.alarma.set('Normal' if alarma == 0 else f'Alarma {alarma}')
                elif kind == 'error':
                    self.connection.set(payload)
                elif kind == 'disconnected':
                    self.start_button.configure(state='disabled')
                    self.stop_button.configure(state='disabled')
                    self.btn_connect.configure(state='normal')
                    self.mode_box.configure(state='readonly')
                    self.estado.set('SIN DATOS')
        except queue.Empty:
            pass
        self.root.after(150, self.process_events)

    def disconnect(self):
        self.stop_event.set()
        self.sim_running = False
        self.start_button.configure(state='disabled')
        self.stop_button.configure(state='disabled')
        self.btn_connect.configure(state='normal')
        self.mode_box.configure(state='readonly')
        self.connection.set('Desconectado (no equivale a una parada de seguridad)')
        self.estado.set('SIN DATOS')

    def close(self):
        self.stop_event.set()
        self.root.destroy()


if __name__ == '__main__':
    window = tk.Tk()
    MiniScada(window)
    window.mainloop()
