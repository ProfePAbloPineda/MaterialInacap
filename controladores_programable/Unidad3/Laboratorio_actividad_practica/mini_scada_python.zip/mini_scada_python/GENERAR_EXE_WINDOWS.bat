@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  echo Instale Python 3.10+ para generar el EXE.
  pause
  exit /b 1
)
py -3 -m venv .venv
if errorlevel 1 goto fallo
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fallo
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name MiniSCADA mini_scada.py
if errorlevel 1 goto fallo
echo Archivo generado en dist\MiniSCADA.exe
pause
exit /b 0
:fallo
echo Error al generar el ejecutable.
pause
exit /b 1
